package com.pharos.indexer;

import com.pharos.config.EmbeddingProviderConfig;
import com.pharos.config.IndexConfig;
import com.pharos.config.ProjectMeta;
import com.pharos.config.ProjectRegistry;
import com.pharos.embedding.EmbeddingProvider;
import com.pharos.parser.JavaCodeParser;
import com.pharos.parser.model.ParsedClass;
import com.pharos.parser.model.ParsedFile;
import com.pharos.parser.model.ParsedMethod;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.*;
import org.apache.lucene.document.IntPoint;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.DocIdSetIterator;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.util.BytesRef;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.function.ToIntFunction;
import java.util.stream.Collectors;

/**
 * Adds (or refreshes) one embedding model's vectors against an existing Lucene
 * index without re-running parsing or the call-graph build. Used by the
 * {@code pharos embed --model=<id> <project>} CLI to compare embedding models
 * cheaply: index once with model A, then drop in model B via this class
 * instead of paying the full parse + graph cost again.
 *
 * <h3>What it does</h3>
 * <ol>
 *   <li>Walks the existing Lucene index; for every {@link Document}, reads its
 *       stored fields and all per-model {@code vec.*} vectors via
 *       {@link FloatVectorValues}.</li>
 *   <li>Skips docs that already carry a {@code vec.<targetModelId>} field
 *       (unless {@code force=true}) — idempotency property.</li>
 *   <li>Re-parses the source file the doc came from, locates the matching
 *       {@link ParsedMethod} or {@link ParsedClass}, builds its embedding text
 *       via {@link DocumentMapper}, and embeds it with the target provider.</li>
 *   <li>Rebuilds the Lucene {@link Document} with all original stored fields,
 *       the existing per-model vectors re-attached, and the new
 *       {@code vec.<targetModelId>} added; commits via
 *       {@link IndexWriter#updateDocument} which is atomic delete-then-add.</li>
 *   <li>Updates {@link ProjectMeta#getEmbeddedModels()} so the search engine's
 *       per-project model-availability validation accepts the new id.</li>
 * </ol>
 *
 * <h3>v1 scope</h3>
 * Only single-chunk documents are processed. Multi-chunk docs (long methods
 * that the chunker split into N chunks during indexing) are skipped with a
 * count in the summary — for those a {@code pharos index --full} re-index is
 * the supported path, since recomputing per-chunk embeddings here would
 * require re-running the chunker over the source file for every affected doc.
 *
 * <p>Only Java sources are re-parsed in v1 (mirrors {@link EmbeddingCacheBackfiller}).
 * Non-Java docs are skipped with a count in the summary.
 */
public class MultiModelEmbedder {

    private static final Logger log = LoggerFactory.getLogger(MultiModelEmbedder.class);

    private final IndexConfig config;
    private final LuceneIndexer luceneIndexer;
    private final ProjectRegistry registry;
    private final JavaCodeParser parser;
    private final Chunker chunker;

    /** Providers already built by the process (Main's indexing providers), by modelId. */
    private final java.util.Map<String, EmbeddingProvider> providers = new java.util.concurrent.ConcurrentHashMap<>();

    public MultiModelEmbedder(IndexConfig config, LuceneIndexer luceneIndexer,
                               ProjectRegistry registry) {
        this(config, luceneIndexer, registry, List.of());
    }

    /**
     * @param loadedProviders providers the process already built; the one matching the
     *                        requested model is reused instead of loading the model again
     *                        (and a model created here is reused for every project of an
     *                        {@code --all} run)
     */
    public MultiModelEmbedder(IndexConfig config, LuceneIndexer luceneIndexer,
                               ProjectRegistry registry, List<EmbeddingProvider> loadedProviders) {
        for (EmbeddingProvider p : loadedProviders) providers.putIfAbsent(p.modelId(), p);
        this.config = config;
        this.luceneIndexer = luceneIndexer;
        this.registry = registry;
        this.parser = new JavaCodeParser();
        this.chunker = new DefaultChunker();
    }

    /** The process's provider for {@code cfg}'s model, created (once) only if none was loaded. */
    EmbeddingProvider providerFor(EmbeddingProviderConfig cfg) {
        return providers.computeIfAbsent(cfg.getModelId(), id -> EmbeddingProvider.create(cfg));
    }

    /** Returns the count of documents updated (excluding skips). */
    public int embed(String projectName, String modelId, boolean force) throws IOException {
        ProjectMeta meta = registry.find(projectName)
                .orElseThrow(() -> new IllegalArgumentException("Unknown project: " + projectName));

        EmbeddingProviderConfig cfg = config.findProviderConfig(modelId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Embedding model '" + modelId + "' not declared in config.embeddingProviders. " +
                        "Add an entry to ~/.pharos/config.json first."));
        // Reuse the process's instance of this model (or one created by an earlier project of
        // this run): every create() loads another copy of the weights (~1.1 GB for ONNX).
        EmbeddingProvider provider = providerFor(cfg);
        if (!provider.isAvailable()) {
            throw new IllegalStateException(
                    "Provider '" + modelId + "' is unavailable (failed to load). Aborting.");
        }
        return embed(meta, provider, IndexVersions.modelFingerprint(cfg),
                IndexVersions.legacyFingerprints(cfg), force);
    }

    /** {@link #embed(ProjectMeta, EmbeddingProvider, String, List, boolean)} with no legacy fingerprints. */
    int embed(ProjectMeta meta, EmbeddingProvider provider, String fingerprint,
              boolean force) throws IOException {
        return embed(meta, provider, fingerprint, List.of(), force);
    }

    /** Core of {@link #embed(String, String, boolean)} with an already-resolved provider. */
    int embed(ProjectMeta meta, EmbeddingProvider provider, String fingerprint,
              List<String> legacyFingerprints, boolean force) throws IOException {
        String projectName = meta.getName();
        String modelId = provider.modelId();
        String targetField = DocumentMapper.vectorFieldFor(modelId);
        // Refuse names whose dir is not a direct child of the index root before any write.
        ProjectNames.resolveProjectDir(luceneIndexer.getIndexDir(), projectName);
        Path projectIndexDir = luceneIndexer.getProjectIndexDir(projectName);
        // Per-model file: sharing embed-cache.bin with the indexing model meant this command
        // invalidated (and deleted) that model's cache.
        PersistentEmbeddingCache cache = PersistentEmbeddingCache.forModel(
                projectIndexDir, modelId, fingerprint, legacyFingerprints, provider.dimensions());

        // ── Phase 1: collect per-doc info from the existing index ─────────────
        // For each docId in each segment: its FQN, file path, chunk count, and
        // every per-model vector currently attached. Per-model chunkVec.* values
        // are kept too so we can re-attach them in the rebuilt doc.
        // One snapshot per Lucene document. Do NOT key by id: pharos ids are not unique
        // (same simple-named types in different files, doc files sharing a stem, …), and
        // keying by id silently collapsed those docs into one.
        List<DocSnapshot> snapshots = new ArrayList<>();
        IndexReader reader = luceneIndexer.openReader(projectName);
        Set<String> vecFieldNames = collectVectorFieldNames(reader);

        for (LeafReaderContext ctx : reader.leaves()) {
            LeafReader leaf = ctx.reader();
            StoredFields sf = leaf.storedFields();
            // Per-model FloatVectorValues iterators — built lazily.
            Map<String, FloatVectorValues> vecsByField = new HashMap<>();
            Map<String, KnnVectorValues.DocIndexIterator> iters = new HashMap<>();
            for (String fn : vecFieldNames) {
                FloatVectorValues fvv = leaf.getFloatVectorValues(fn);
                if (fvv != null) {
                    vecsByField.put(fn, fvv);
                    iters.put(fn, fvv.iterator());
                }
            }

            // Iterate by docId so the per-field iterators advance in lock-step.
            // Using the dominant target field's iterator as the driver — if the
            // target model isn't yet in this leaf, any other vec.* field works.
            DocIdSetIterator driver = chooseDriverIterator(iters);
            if (driver == null) continue;  // no vector data at all in this leaf

            int docId;
            while ((docId = driver.nextDoc()) != DocIdSetIterator.NO_MORE_DOCS) {
                Document doc = sf.document(docId);
                String id = doc.get(DocumentMapper.F_ID);
                if (id == null) continue;

                DocSnapshot snap = new DocSnapshot();
                snap.id        = id;
                snap.filePath  = doc.get(DocumentMapper.F_FILE_PATH);
                snap.docType   = doc.get(DocumentMapper.F_DOC_TYPE);
                snap.scope     = doc.get(DocumentMapper.F_SCOPE);
                IndexableField sl = doc.getField(DocumentMapper.F_START_LINE);
                snap.startLine = sl != null && sl.numericValue() != null ? sl.numericValue().intValue() : -1;
                IndexableField deg = doc.getField(DocumentMapper.F_IN_DEGREE);
                snap.inDegree  = deg != null && deg.numericValue() != null ? deg.numericValue().intValue() : 0;
                String callers = doc.get(DocumentMapper.F_CALLER_CONTEXT);
                snap.callerNames = callers == null || callers.isBlank()
                        ? List.of() : List.of(callers.trim().split("\\s+"));

                // Detect multi-chunk docs via the chunk-line-ranges marker.
                BytesRef rangesRef = doc.getBinaryValue(DocumentMapper.F_CHUNK_LINE_RANGES);
                int chunkCount = (rangesRef != null)
                        ? DocumentMapper.decodeLineRanges(rangesRef.bytes).length
                        : 1;
                snap.chunkCount = chunkCount;

                // Read every per-model vector field for this docId. Iterators
                // must be advanced separately for fields that lag behind.
                for (Map.Entry<String, FloatVectorValues> e : vecsByField.entrySet()) {
                    String fn = e.getKey();
                    FloatVectorValues fvv = e.getValue();
                    KnnVectorValues.DocIndexIterator it = iters.get(fn);
                    while (it.docID() < docId && it.nextDoc() != DocIdSetIterator.NO_MORE_DOCS) {
                        // advance to docId
                    }
                    if (it.docID() == docId) {
                        snap.vectorsByField.put(fn, fvv.vectorValue(it.index()).clone());
                    }
                }

                // Read per-model chunkVec.* binary fields (LateInteractionField
                // payloads). Their field name mirrors vec.* but with chunkVec.* prefix.
                for (org.apache.lucene.index.IndexableField f : doc.getFields()) {
                    String name = f.name();
                    if (name.startsWith("chunkVec.") || DocumentMapper.F_CHUNK_VECTORS_LEGACY.equals(name)) {
                        BytesRef br = doc.getBinaryValue(name);
                        if (br != null) snap.chunkVecsByField.put(name, br.bytes.clone());
                    }
                }
                snapshots.add(snap);
            }
        }

        log.info("Embed '{}': scanned {} doc(s) in '{}'", modelId, snapshots.size(), projectName);

        // ── Phase 2: group by file, parse, embed, updateDocument ─────────────
        Map<String, List<DocSnapshot>> byFile = new LinkedHashMap<>();
        for (DocSnapshot s : snapshots) {
            if (s.filePath == null) continue;
            byFile.computeIfAbsent(s.filePath, k -> new ArrayList<>()).add(s);
        }

        int updated = 0, skippedExisting = 0, skippedMultiChunk = 0;
        int skippedNonJava = 0, skippedMissingFile = 0, skippedNoMatch = 0;

        try (IndexWriter writer = luceneIndexer.openWriter(projectName)) {
            for (Map.Entry<String, List<DocSnapshot>> entry : byFile.entrySet()) {
                Path filePath = Path.of(entry.getKey());
                if (!Files.exists(filePath)) {
                    skippedMissingFile += entry.getValue().size();
                    continue;
                }
                if (!entry.getKey().endsWith(".java")) {
                    skippedNonJava += entry.getValue().size();
                    continue;
                }

                ParsedFile parsedFile;
                try {
                    parsedFile = parser.parseFile(filePath, projectName);
                } catch (Exception e) {
                    log.debug("Parse failed for {}: {}", filePath.getFileName(), e.getMessage());
                    continue;
                }
                // Keyed by the same "project:fqn" form as the stored id (the old fqn()/qcn keys
                // never matched, so every doc was skipped). Lists, because one file can still
                // hold several members with the same id; startLine picks the right one.
                Map<String, List<ParsedMethod>> byId = parsedFile.methods().stream()
                        .collect(Collectors.groupingBy(ParsedMethod::id));
                Map<String, List<ParsedClass>> byClassId = parsedFile.classes().stream()
                        .collect(Collectors.groupingBy(c -> projectName + ":" + c.qualifiedClassName()));
                List<String> fileLines;
                try { fileLines = Files.readAllLines(filePath); }
                catch (IOException e) { fileLines = List.of(); }

                // An id that occurs more than once in this file (e.g. stale mis-owned docs from an
                // index built before nested-type ownership was fixed) must match by line exactly:
                // falling back to "the only parsed candidate" would rewrite the stale doc as a
                // second copy of the real one.
                Map<String, Long> idsInFile = entry.getValue().stream()
                        .collect(Collectors.groupingBy(sn -> sn.id, Collectors.counting()));
                for (DocSnapshot snap : entry.getValue()) {
                    // v1 limitation: skip multi-chunk docs.
                    if (snap.chunkCount > 1) { skippedMultiChunk++; continue; }
                    // Without a start line the doc can't be addressed uniquely (see docKeyQuery);
                    // updateDocuments would only add, duplicating it.
                    if (snap.startLine < 0) { skippedNoMatch++; continue; }
                    snap.idUniqueInFile = idsInFile.getOrDefault(snap.id, 0L) == 1;
                    // Idempotency: skip if the target field is already present and !force.
                    if (!force && snap.vectorsByField.containsKey(targetField)) {
                        skippedExisting++;
                        continue;
                    }

                    Document fresh = buildUpdatedDoc(snap, byId, byClassId, fileLines,
                            provider, targetField, cache, projectName);
                    if (fresh == null) { skippedNoMatch++; continue; }
                    // Replace exactly this document. updateDocument(Term(id)) would delete every
                    // doc sharing the id and write back only one of them.
                    writer.updateDocuments(docKeyQuery(snap), List.of(fresh));
                    updated++;
                }
            }
            writer.commit();
        }

        if (cache != null) cache.save();

        // ── Phase 3: bookkeeping ─────────────────────────────────────────────
        List<String> embedded = new ArrayList<>(meta.getEmbeddedModels());
        if (!embedded.contains(modelId)) {
            embedded.add(modelId);
            meta.setEmbeddedModels(embedded);
            registry.register(meta);
        }

        System.out.printf("Embed '%s' for '%s': %d updated, %d already present, " +
                "%d multi-chunk skipped, %d non-java skipped, %d missing-file skipped, %d no-match skipped%n",
                modelId, projectName, updated, skippedExisting, skippedMultiChunk,
                skippedNonJava, skippedMissingFile, skippedNoMatch);
        return updated;
    }

    /**
     * Rebuilds a Lucene document by re-parsing its source file, embedding the
     * target model's vector, and re-attaching every existing per-model vector
     * from the snapshot. Returns null when the FQN can't be matched in the
     * freshly parsed file (e.g. the source moved or was renamed).
     */
    private Document buildUpdatedDoc(DocSnapshot snap, Map<String, List<ParsedMethod>> byId,
                                      Map<String, List<ParsedClass>> byClassId, List<String> fileLines,
                                      EmbeddingProvider provider, String targetField,
                                      PersistentEmbeddingCache cache,
                                      String projectName) {
        // Build the per-model vector map: existing fields (other models) +
        // the freshly-embedded target. Each existing vec.* field name maps to
        // its modelId by stripping the "vec." prefix.
        Map<String, float[]> vectorsByModel = new LinkedHashMap<>();
        for (Map.Entry<String, float[]> e : snap.vectorsByField.entrySet()) {
            String fn = e.getKey();
            // Skip the target field — we're about to overwrite it with a fresh value.
            if (fn.equals(targetField)) continue;
            String existingModelId = modelIdFromFieldName(fn);
            if (existingModelId != null) vectorsByModel.put(existingModelId, e.getValue());
        }

        if ("method".equals(snap.docType) || "chunk".equals(snap.docType)) {
            ParsedMethod method = pick(byId.get(snap.id), snap.startLine, ParsedMethod::startLine, snap.idUniqueInFile);
            if (method == null) return null;
            String text = DocumentMapper.buildEmbeddingText(method);
            float[] vec = embedWithCache(provider, text, cache);
            if (vec == null) return null;
            vectorsByModel.put(provider.modelId(), vec);
            // Graph-derived fields are carried over from the existing doc (the graph is not
            // rebuilt here); previously they were reset to 0 / empty on every rewrite.
            return DocumentMapper.toDocument(method, vectorsByModel, snap.inDegree, snap.callerNames, fileLines);
        } else if ("class".equals(snap.docType) || "document".equals(snap.docType)) {
            ParsedClass cls = pick(byClassId.get(snap.id), snap.startLine, ParsedClass::startLine, snap.idUniqueInFile);
            if (cls == null) return null;
            String synthBody = synthesizedBody(cls);
            String text = DocumentMapper.buildClassEmbeddingText(cls, synthBody);
            float[] vec = embedWithCache(provider, text, cache);
            if (vec == null) return null;
            vectorsByModel.put(provider.modelId(), vec);
            return DocumentMapper.toClassDocument(cls, synthBody, vectorsByModel);
        }
        return null;
    }

    /**
     * Chooses the parsed member that produced a doc: the candidate declared on the same start
     * line or — when {@code allowLineMoved} (the doc's id is unique in its file) — the only
     * candidate. Null when ambiguous or stale.
     */
    static <T> T pick(List<T> candidates, int startLine, ToIntFunction<T> line, boolean allowLineMoved) {
        if (candidates == null || candidates.isEmpty()) return null;
        for (T c : candidates) if (line.applyAsInt(c) == startLine) return c;
        return allowLineMoved && candidates.size() == 1 ? candidates.get(0) : null;
    }

    /**
     * Matches exactly one document: (docType, filePath, startLine) is unique within a project
     * index, unlike the id. All three are indexed in every existing index, so this needs no
     * re-index or schema change.
     */
    static Query docKeyQuery(DocSnapshot snap) {
        BooleanQuery.Builder b = new BooleanQuery.Builder()
                .add(new TermQuery(new Term(DocumentMapper.F_ID, snap.id)), BooleanClause.Occur.FILTER)
                .add(new TermQuery(new Term(DocumentMapper.F_FILE_PATH, snap.filePath)), BooleanClause.Occur.FILTER)
                .add(IntPoint.newExactQuery(DocumentMapper.F_START_LINE, snap.startLine), BooleanClause.Occur.FILTER);
        if (snap.docType != null) {
            b.add(new TermQuery(new Term(DocumentMapper.F_DOC_TYPE, snap.docType)), BooleanClause.Occur.FILTER);
        }
        return b.build();
    }

    /** Persistent-cache wrapper around a single embed() call. */
    private static float[] embedWithCache(EmbeddingProvider provider, String text,
                                           PersistentEmbeddingCache cache) {
        if (text == null || text.isBlank()) return null;
        if (cache != null) {
            String key = PersistentEmbeddingCache.sha256Hex(text);
            float[] cached = cache.get(key);
            if (cached != null) return cached;
            float[] fresh = provider.embed(text);
            if (fresh != null) cache.put(key, fresh);
            return fresh;
        }
        return provider.embed(text);
    }

    /** Strip {@code vec.} prefix and return null for the legacy field. */
    private static String modelIdFromFieldName(String fieldName) {
        if (fieldName == null) return null;
        if (DocumentMapper.F_VECTOR_LEGACY.equals(fieldName)) return IndexConfig.LEGACY_MODEL_ID;
        if (fieldName.startsWith("vec.")) return fieldName.substring("vec.".length());
        return null;
    }

    /**
     * Scans the reader's leaf field infos for every Lucene KNN vector field.
     * Used to know which per-model vectors need to be preserved when rewriting
     * a doc via {@link IndexWriter#updateDocument}.
     */
    private static Set<String> collectVectorFieldNames(IndexReader reader) {
        Set<String> out = new LinkedHashSet<>();
        for (LeafReaderContext ctx : reader.leaves()) {
            FieldInfos fis = ctx.reader().getFieldInfos();
            for (FieldInfo fi : fis) {
                if (fi.getVectorDimension() > 0) out.add(fi.name);
            }
        }
        return out;
    }

    /** Pick any iterator — they all iterate in docId order, so any works as the driver. */
    private static DocIdSetIterator chooseDriverIterator(
            Map<String, KnnVectorValues.DocIndexIterator> iters) {
        return iters.values().stream().findFirst().orElse(null);
    }

    /** Build the same synthesized body the full indexer would produce for this class. */
    private String synthesizedBody(ParsedClass cls) {
        if ("document".equals(cls.kind())) {
            return DocumentMapper.readBodyFromFile(cls.filePath(), cls.startLine(), cls.endLine(), null);
        }
        // Best-effort: signatures + javadoc of the class's methods.
        return "";
    }

    /** Snapshot of one doc as it exists in the source Lucene index. */
    static final class DocSnapshot {
        String id;
        String filePath;
        String docType;
        String scope;
        int startLine;
        /** True when no other snapshot in the same file has this id. */
        boolean idUniqueInFile;
        int inDegree;
        List<String> callerNames = List.of();
        int chunkCount;
        /** fieldName → float[] (existing per-model KNN vectors). */
        final Map<String, float[]>  vectorsByField   = new LinkedHashMap<>();
        /** fieldName → encoded LateInteractionField bytes (currently informational). */
        final Map<String, byte[]>   chunkVecsByField = new LinkedHashMap<>();
    }
}
