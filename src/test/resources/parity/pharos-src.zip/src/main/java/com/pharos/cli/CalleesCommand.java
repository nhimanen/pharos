package com.pharos.cli;

import com.pharos.indexer.IncompatibleIndexException;
import com.pharos.config.IndexConfig;
import com.pharos.config.ProjectMeta;
import com.pharos.config.ProjectRegistry;
import com.pharos.graph.GraphView;
import com.pharos.graph.GraphViews;
import com.pharos.search.SearchEngine;
import com.pharos.search.SearchResult;
import picocli.CommandLine.*;

import java.util.*;
import java.util.concurrent.Callable;

@Command(
        name = "callees",
        description = "Show all methods called by the given method FQN",
        mixinStandardHelpOptions = true
)
public class CalleesCommand implements Callable<Integer> {

    @Parameters(index = "0", description = "Fully qualified method: com.example.MyClass#myMethod(String,int)")
    private String fqn;

    @Option(names = {"--project", "-p"}, description = "Restrict to a specific project")
    private String project;

    private final SearchEngine searchEngine;
    private final ProjectRegistry registry;

    public CalleesCommand(SearchEngine searchEngine, ProjectRegistry registry, IndexConfig config) {
        this.searchEngine = searchEngine;
        this.registry = registry;
    }

    @Override
    public Integer call() {
        try {
            // Try graph-based lookup first
            Set<String> callees = getCalleesFromGraph(fqn);

            if (callees.isEmpty()) {
                // Fall back to Lucene
                List<SearchResult> results = searchEngine.findCallees(fqn, project);
                if (results.isEmpty()) {
                    System.out.println("No callees found for: " + fqn);
                } else {
                    System.out.printf("Methods called by %s (%d):%n", fqn, results.size());
                    results.forEach(r -> System.out.printf("  %s [%s:%d]%n",
                            r.label(), r.filePath(), r.startLine()));
                }
            } else {
                System.out.printf("Methods called by %s (%d):%n", fqn, callees.size());
                callees.forEach(c -> System.out.printf("  %s%n", c));
            }
            return 0;
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            return 1;
        }
    }

    private Set<String> getCalleesFromGraph(String callerFqn) {
        List<ProjectMeta> projects = project != null
                ? registry.find(project).map(List::of).orElse(List.of())
                : registry.listAll();

        Set<String> allCallees = new LinkedHashSet<>();
        for (ProjectMeta meta : projects) {
            // GraphViews checks the index format before opening anything
            try (GraphView graph = GraphViews.open(meta)) {
                allCallees.addAll(graph.callees(callerFqn));
            } catch (IncompatibleIndexException e) {
                if (project != null) throw e;  // explicitly requested: surface it
                // all-project: skip the incompatible one
            } catch (Exception e) {
                // Graph not available for this project
            }
        }
        return allCallees;
    }
}
