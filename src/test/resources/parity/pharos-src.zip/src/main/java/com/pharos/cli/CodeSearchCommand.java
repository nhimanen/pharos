package com.pharos.cli;

import picocli.CommandLine;
import picocli.CommandLine.*;

/**
 * Root picocli command. Prints help if invoked with no subcommand.
 */
@Command(
        name = "pharos",
        description = "Code-aware search tool with BM25 + vector search and call graph analysis",
        subcommands = {
                IndexCommand.class,
                SearchCommand.class,
                GetMethodCommand.class,
                CallersCommand.class,
                CalleesCommand.class,
                GetClassCommand.class,
                UsagesCommand.class,
                TraceCallChainCommand.class,
                TransitiveCallersCommand.class,
                PathCommand.class,
                ProjectsCommand.class,
                LinkCommand.class,
                StatsCommand.class,
                ModulesCommand.class,
                ModuleDepsCommand.class,
                ModulePathCommand.class,
                McpServerCommand.class,
                WebCommand.class,
                RemoveIndexCommand.class,
                BackfillEmbeddingCacheCommand.class,
                MineCommand.class,
                EmbedCommand.class,
                IndexStatusCommand.class,
                UpgradeIndexesCommand.class,
                PublishCommand.class,
                CommandLine.HelpCommand.class
        },
        mixinStandardHelpOptions = true,
        versionProvider = PharosVersionProvider.class
)
public class CodeSearchCommand implements Runnable {

    @Override
    public void run() {
        CommandLine.usage(this, System.out);
    }
}
